// const fs = require("fs");
const express = require("express");
const router = express.Router();
// var path = require('path');
const con = require('./sqlConnection').connection;
var BookObj = [];
router.post('/SaveBookDetails', (req, res) => {
    let BookName = req.body.book;
    let existing_details = filterdata(BookObj, 'BookTitle', BookName);
    if (existing_details == false) {
        BookObj.push({ 'BookTitle': BookName });
        res.json({ RESULT: 'Book Saved Successfully.' });
    } else {
        res.json({ RESULT: 'Book Already exists!' })
    }
});
router.delete('/DeleteBookDetails', (req, res) => {
    let BookName = req.body.book;
    let existing_details = filterdata(BookObj, 'BookTitle', BookName);
    if (existing_details == false) {
        res.json({ RESULT: 'Book dose not exists.' });
    } else {
        let number;
        let num = BookObj.filter(function (i, n) {
            if (i['BookTitle'].toString().toLowerCase() == BookName.toString().toLowerCase())
                number = n;
        });
        BookObj.splice(number, 1);
        res.json({ RESULT: 'Book Delete Successfully!' })
    }
});
router.patch('/PatchBookDetails', (req, res) => {
    let BookName = req.body;
    let existing_details = filterdata(BookObj, 'BookTitle', BookName[0]['original_book']);
    if (existing_details == false) {
        res.json({ RESULT: 'Book dose not exists.' });
    } else {
        let number;
        let num = BookObj.filter(function (i, n) {
            if (i['BookTitle'].toString().toLowerCase() == BookName[0]['original_book'].toString().toLowerCase())
                number = n;
        });
        BookObj[number]['BookTitle'] = BookName[0]['new_book'];
        res.json({ RESULT: 'Book updated Successfully!' });
    }
});
async function getBookList(list, index, callback, resultset) {
    if (index < list.length) {
        resultset.push(list[index].BookTitle);
        index = index + 1
        getBookList(list, index, callback, resultset)
    } else {
        return callback(resultset);
    }
}
router.get('/GetBookDetails', async (req, res) => {
    let result;
    await getBookList(BookObj, 0, function result1(res) {
        result = res;
    }, []);
    if (result && result.length == 0) {
        res.json({ RESULT: 'Result dose not exists.' });
    } else {
        res.json(result);
    }
});
var rand;
router.put('/PutBookDetails', async (req, res) => {
    let result = [];
    let i = 0;
    let name = '';
    rand = Math.round(Math.random() * (3000 - 500)) + 500;
    let myInterval = setInterval(async function () {
        name = (BookObj[i] && BookObj[i] !== undefined ? BookObj[i].BookTitle : '');
        if (i < BookObj.length) {
            await saveItemOnDatabase(BookObj[i].BookTitle, function result2(res) {
                result.push(res);
            });
            i = i + 1;
        } else {
            clearInterval(myInterval);
            if (result && result.length == 0) {
                res.json({ RESULT: 'Result dose not exists.' });
            } else {
                res.json(result);
            }
        }
    }, +(rand + name.length));
});
async function saveItemOnDatabase(bookNames, callback) {
    rand = Math.round(Math.random() * (3000 - 500)) + 500;
    var sql = `inser into BookDetails (bookname) values('${bookNames}');`;
    let varRes = {};
    varRes[bookNames] = rand;
    con.query(sql, (error, sqlResult) => {
        if (error) {
            callback(JSON.stringify({ 'err': "X", msg: "Contact Developers " + error }));
        } else {
            callback(JSON.stringify({ bookName: rand }));
        }
    });
    callback(varRes);
}
function filterdata(FilterArr, keyobj, valobj) {
    FilterArr = FilterArr.filter(function (i, n) {
        return (i[keyobj].toString().toLowerCase() == valobj.toString().toLowerCase());
    });
    if (FilterArr.length > 0)
        return true;
    else
        return false;
}
module.exports = router;