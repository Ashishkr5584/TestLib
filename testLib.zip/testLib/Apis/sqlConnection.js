"use strict";
/**
 * Module dependencies.
 */
const fs = require("fs");
const mysql = require("mysql");
let config = fs.readFileSync("connectionString.txt", "utf8");
// create mysql connection pool
const connection = mysql.createPool(JSON.parse(config));
//get connection from connection pool
connection.getConnection(function (err) {
    if (err) throw err;
    console.log("Database Connect")
});
module.exports = {
    connection
};